const mongoose = require('mongoose');
const Schema = mongoose.Schema;

//'services' table schema 
const serviceSchema = new Schema({
  provider: {
    type: Schema.Types.ObjectId,
    ref: 'User', // Links to the User model
    required: true,
  },
  serviceName: { type: String, required: true },
  serviceDescription: { type: String, required: true },
  paymentAmount: { type: Number, required: true },
  // This will be dynamically calculated from the 'Rating' model
  providerOverallRating: { type: Number, default: 0.0 },
}, { timestamps: true });

module.exports = mongoose.model('Service', serviceSchema);