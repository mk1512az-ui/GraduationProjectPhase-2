const mongoose = require('mongoose');
const Schema = mongoose.Schema;

//'bills' table schema
const billSchema = new Schema({
  senior: {
    type: Schema.Types.ObjectId,
    ref: 'User', 
    required: true,
  },
  provider: {
    type: Schema.Types.ObjectId,
    ref: 'User',
    required: true,
  },
  booking: { 
    type: Schema.Types.ObjectId,
    ref: 'Booking',
    required: true,
  },
  amount: { type: Number, required: true },
  status: {
    type: String,
    enum: ['Pending', 'Paid', 'Cancelled'],
    default: 'Pending',
  },
}, { timestamps: true });

module.exports = mongoose.model('Bill', billSchema);