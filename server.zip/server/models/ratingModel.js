const mongoose = require('mongoose');
const Schema = mongoose.Schema;

//'ratings' table schema
const ratingSchema = new Schema({
  senior: {
    type: Schema.Types.ObjectId,
    ref: 'User',
    required: true,
  },
  provider: {
    type: Schema.Types.ObjectId,
    ref: 'User',
    required: true,
  },
  rating: { type: Number, min: 1, max: 5, required: true },
  comment: { type: String },
}, { timestamps: true });

// After a new rating is saved, update the provider's average rating
ratingSchema.statics.calculateAverageRating = async function(providerId) {
  const stats = await this.aggregate([
    { $match: { provider: providerId } },
    { $group: { _id: '$provider', averageRating: { $avg: '$rating' } } }
  ]);

  try {
    if (stats.length > 0) {
      await mongoose.model('User').findByIdAndUpdate(providerId, {
        rating: stats[0].averageRating.toFixed(1)
      });
    } else {
      await mongoose.model('User').findByIdAndUpdate(providerId, {
        rating: 0
      });
    }
  } catch (err) {
    console.error(err);
  }
};

ratingSchema.post('save', function() {
  this.constructor.calculateAverageRating(this.provider);
});

module.exports = mongoose.model('Rating', ratingSchema);