require('dotenv').config();
const express = require('express');
const mongoose = require('mongoose');
const cors = require('cors');

//1. Import all routes
const authRoutes = require('./routes/authRoutes');
const serviceRoutes = require('./routes/serviceRoutes');
const bookingRoutes = require('./routes/bookingRoutes');
const adminRoutes = require('./routes/adminRoutes');
const recommendationRoutes = require('./routes/recommendationRoutes');
const billRoutes = require('./routes/billRoutes');
const ratingRoutes = require('./routes/ratingRoutes');

const app = express();

//2. Middleware
app.use(cors());
app.use(express.json());

//3. Database Connection
mongoose.connect(process.env.MONGO_URI, {
  useNewUrlParser: true,
  useUnifiedTopology: true,
})
.then(() => console.log('MongoDB connected successfully.'))
.catch(err => console.error('MongoDB connection error:', err));

//4. API Routes
app.get('/', (req, res) => {
  res.send('Reciplink API is running...');
});

app.use('/api/auth', authRoutes);
app.use('/api/services', serviceRoutes);
app.use('/api/bookings', bookingRoutes);
app.use('/api/admin', adminRoutes);
app.use('/api/recommendations', recommendationRoutes);
app.use('/api/bills', billRoutes);
app.use('/api/ratings', ratingRoutes);

//Start Server
const PORT = process.env.PORT || 5001;
app.listen(PORT, () => console.log(`Server running on http://localhost:${PORT}`));