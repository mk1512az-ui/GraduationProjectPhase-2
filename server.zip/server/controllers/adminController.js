const User = require('../models/userModel');
const Service = require('../models/serviceModel');
const Booking = require('../models/bookingModel');
const Bill = require('../models/billModel');
// ---

//Get all users (Seniors and Providers)
//Private (Admin only)
const getAllUsers = async (req, res) => {
  try {
    const users = await User.find({}).select('-password');
    res.json(users);
  } catch (error) {
    res.status(500).json({ message: error.message });
  }
};

//Get a single user by ID
//GET /api/admin/users/:id
//Private (Admin only)
const getUserById = async (req, res) => {
    try {
        const user = await User.findById(req.params.id).select('-password');
        if (user) {
            res.json(user);
        } else {
            res.status(404).json({ message: 'User not found' });
        }
    } catch (error) {
        res.status(500).json({ message: error.message });
    }
};

//Update any user
//PUT /api/admin/users/:id
//Private (Admin only)
const updateUser = async (req, res) => {
    try {
        const user = await User.findById(req.params.id);
        if (!user) {
            return res.status(404).json({ message: 'User not found' });
        }
        
        user.name = req.body.name || user.name;
        user.email = req.body.email || user.email;
        user.role = req.body.role || user.role;
        user.age = req.body.age || user.age;
        // Admin can also update medical info, etc.
        user.medicalSummary = req.body.medicalSummary || user.medicalSummary;

        const updatedUser = await user.save();
        res.json(updatedUser);
    } catch (error) {
        res.status(500).json({ message: error.message });
    }
};

//Delete a user
//DELETE /api/admin/users/:id
//Private (Admin only)
const deleteUser = async (req, res) => {
  try {
    const user = await User.findById(req.params.id);
    if (user) {
      //Also delete related services, bookings, etc.
      await user.deleteOne();
      res.json({ message: 'User removed' });
    } else {
      res.status(404).json({ message: 'User not found' });
    }
  } catch (error) {
    res.status(500).json({ message: error.message });
  }
};

//Get ALL services from all providers
//GET /api/admin/services
//Private (Admin only)
const getAllServices = async (req, res) => {
    try {
        const services = await Service.find({}).populate('provider', 'name email');
        res.json(services);
    } catch (error) {
        res.status(500).json({ message: error.message });
    }
};

//Get ALL bookings on the platform
//GET /api/admin/bookings
//Private (Admin only)
const getAllBookings = async (req, res) => {
    try {
        const bookings = await Booking.find({})
            .populate('senior', 'name')
            .populate('provider', 'name')
            .populate('service', 'serviceName');
        res.json(bookings);
    } catch (error) {
        res.status(500).json({ message: error.message });
    }
};

//Get ALL bills on the platform
//GET /api/admin/bills
//Private (Admin only)
const getAllBills = async (req, res) => {
    try {
        const bills = await Bill.find({})
            .populate('senior', 'name')
            .populate('provider', 'name')
            .populate('booking', 'bookingDate');
        res.json(bills);
    } catch (error) {
        res.status(500).json({ message: error.message });
    }
};

module.exports = {
  getAllUsers,
  getUserById,
  updateUser,
  deleteUser,
  getAllServices,
  getAllBookings,
  getAllBills,
};