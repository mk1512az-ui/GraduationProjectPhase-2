const Booking = require('../models/bookingModel');
const Service = require('../models/serviceModel');
const Bill = require('../models/billModel');

//Create a new booking
//POST /api/bookings
//Private (Senior only)
const createBooking = async (req, res) => {
  const { serviceId, bookingDate } = req.body;

  try {
    const service = await Service.findById(serviceId);
    if (!service) {
      return res.status(404).json({ message: 'Service not found' });
    }

    const booking = new Booking({
      senior: req.user._id,
      service: serviceId,
      provider: service.provider,
      bookingDate,
      status: 'Pending',
    });
    const createdBooking = await booking.save();

    // Automatically create a bill for this booking
    const bill = new Bill({
        senior: req.user._id,
        provider: service.provider,
        booking: createdBooking._id,
        amount: service.paymentAmount,
        status: 'Pending'
    });
    await bill.save();

    res.status(201).json(createdBooking);
  } catch (error) {
    res.status(500).json({ message: error.message });
  }
};

//Get all bookings for the logged-in user (Senior or Provider)
//GET /api/bookings/my-bookings
//Private
const getMyBookings = async (req, res) => {
  try {
    let bookings;
    if (req.user.role === 'Senior') {
      bookings = await Booking.find({ senior: req.user._id })
        .populate('service', 'serviceName paymentAmount')
        .populate('provider', 'name');
    } else if (req.user.role === 'Provider') {
      bookings = await Booking.find({ provider: req.user._id })
        .populate('service', 'serviceName')
        .populate('senior', 'name email');
    }
    res.json(bookings);
  } catch (error) {
    res.status(500).json({ message: error.message });
  }
};

//Get a single booking by ID
//GET /api/bookings/:id
//Private
const getBookingById = async (req, res) => {
    try {
        const booking = await Booking.findById(req.params.id)
            .populate('service')
            .populate('senior', 'name email')
            .populate('provider', 'name email');
        
        if (!booking) {
            return res.status(404).json({ message: 'Booking not found' });
        }

        //must be the senior or provider associated with the booking
        if (booking.senior._id.toString() !== req.user._id.toString() &&
            booking.provider._id.toString() !== req.user._id.toString()) {
            return res.status(401).json({ message: 'Not authorized to view this booking' });
        }
        
        res.json(booking);
    } catch (error) {
        res.status(500).json({ message: error.message });
    }
};

//Update a booking status (e.g., "Confirmed", "Completed")
//PUT /api/bookings/:id/status
//Private (Provider only)
const updateBookingStatus = async (req, res) => {
    try {
        const { status } = req.body; // e.g., "Confirmed", "Completed"
        const booking = await Booking.findById(req.params.id);

        if (!booking) {
            return res.status(404).json({ message: 'Booking not found' });
        }

        // Only the provider on the booking can update its status
        if (booking.provider.toString() !== req.user._id.toString()) {
            return res.status(401).json({ message: 'Not authorized to update this booking' });
        }

        booking.status = status;
        const updatedBooking = await booking.save();
        res.json(updatedBooking);

    } catch (error) {
        res.status(500).json({ message: error.message });
    }
};

//Cancel a booking
//PUT /api/bookings/:id/cancel
//Private (Senior only)
const cancelBooking = async (req, res) => {
    try {
        const booking = await Booking.findById(req.params.id);

        if (!booking) {
            return res.status(404).json({ message: 'Booking not found' });
        }

        // Only the senior who made the booking can cancel it
        if (booking.senior.toString() !== req.user._id.toString()) {
            return res.status(401).json({ message: 'Not authorized to cancel this booking' });
        }

        // Also cancel the associated bill
        await Bill.findOneAndUpdate({ booking: booking._id }, { status: 'Cancelled' });

        booking.status = 'Cancelled';
        const updatedBooking = await booking.save();
        res.json(updatedBooking);

    } catch (error) {
        res.status(500).json({ message: error.message });
    }
};

module.exports = {
  createBooking,
  getMyBookings,
  getBookingById,
  updateBookingStatus,
  cancelBooking,
};