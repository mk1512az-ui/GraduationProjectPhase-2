const axios = require('axios');
const Service = require('../models/serviceModel');

// This is the URL  our Python/Flask ML service that we will add in a later phase
const ML_API_URL = 'http://localhost:8000/get-recommendations'; // Example URL

//Get personalized recommendations for a senior
//GET /api/recommendations/
//Private (for Seniors)
exports.getRecommendations = async (req, res) => {
  try {
    const seniorId = req.user._id;
    const seniorData = {
        userId: seniorId,
        age: req.user.age,
        medicalSummary: req.user.medicalSummary,
        preferences: req.user.preferences
    };

    //testing without Python API
    console.warn('Sending MOCK recommendation data. Connect to Python API.');
    res.json({
        message: "Mock recommendations",
        recommendations: [
            { _id: "mock_service_id_1", serviceName: "Mock: Companion Visit" },
            { _id: "mock_service_id_2", serviceName: "Mock: Meal Delivery" },
        ]
    });
    // End of testing block

  } catch (error) {
    console.error('Error fetching recommendations:', error.message);
    res.status(500).json({ message: 'Error getting recommendations' });
  }
};