const express = require('express');
const router = express.Router();
const {
  createBooking,
  getMyBookings,
  getBookingById,
  updateBookingStatus,
  cancelBooking,
} = require('../controllers/bookingController');
const { protect, authorize } = require('../middleware/authMiddleware');
//Create a new booking
router.post('/', protect, authorize('Senior'), createBooking);
//Get all bookings for the logged-in user (Senior or Provider)
router.get('/my-bookings', protect, authorize('Senior', 'Provider'), getMyBookings);
//Get a single booking by ID
router.get('/:id', protect, authorize('Senior', 'Provider'), getBookingById);
//Update a booking's status (e.g., Confirm, Complete)
router.put('/:id/status', protect, authorize('Provider'), updateBookingStatus);
//Cancel a booking
router.put('/:id/cancel', protect, authorize('Senior'), cancelBooking);

module.exports = router;