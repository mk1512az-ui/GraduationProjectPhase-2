const express = require('express');
const router = express.Router();
const {
  createRating,
  getRatingsForProvider,
} = require('../controllers/ratingController');
const { protect, authorize } = require('../middleware/authMiddleware');
//Create a new rating for a completed service
router.post('/', protect, authorize('Senior'), createRating);
//Get all ratings for a specific provider
// This can be public, so we just use 'protect' to ensure user is logged in
router.get('/provider/:id', protect, getRatingsForProvider);

module.exports = router;