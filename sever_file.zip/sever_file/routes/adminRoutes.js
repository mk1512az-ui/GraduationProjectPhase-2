const express = require('express');
const router = express.Router();
const {
  getAllUsers,
  getUserById,
  updateUser,
  deleteUser,
  getAllServices,
  getAllBookings,
  getAllBills,
} = require('../controllers/adminController');
const { protect, authorize } = require('../middleware/authMiddleware');

// --- ADMIN-ONLY ---
// This middleware ensures only logged-in Admins can access ANY route in this file
router.use(protect, authorize('Admin'));

// --- User Management ---
//Get all users
router.get('/users', getAllUsers);
// Get a single user by ID
router.get('/users/:id', getUserById);
//Update a user's details
router.put('/users/:id', updateUser);
//Delete a user
router.delete('/users/:id', deleteUser);
// --- Data Management ---
//Get all services on the platform
router.get('/services', getAllServices);
//Get all bookings on the platform
router.get('/bookings', getAllBookings);
//Get all bills on the platform
router.get('/bills', getAllBills);


module.exports = router;