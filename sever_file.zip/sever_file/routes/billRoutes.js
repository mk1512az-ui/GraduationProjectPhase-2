const express = require('express');
const router = express.Router();
const {
  getMyBills,
  payBill,
} = require('../controllers/billController');
const { protect, authorize } = require('../middleware/authMiddleware');
//Get all bills for the logged-in user (Senior or Provider)
router.get('/my-bills', protect, authorize('Senior', 'Provider'), getMyBills);
//Mark a bill as paid
router.put('/:id/pay', protect, authorize('Senior'), payBill);

module.exports = router;