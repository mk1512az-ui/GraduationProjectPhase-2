const express = require('express');
const router = express.Router();
const {
  createService,
  getAllServices,
  getServiceById,
  getMyServices,
  updateService,
  deleteService,
} = require('../controllers/serviceController');
const { protect, authorize } = require('../middleware/authMiddleware');
// Get all services from all providers
router.get('/', protect, authorize('Senior', 'Admin'), getAllServices);
// Get all services for the logged-in provider
router.get('/my-services', protect, authorize('Provider'), getMyServices);
//Get a single service by its ID
router.get('/:id', protect, authorize('Senior', 'Admin', 'Provider'), getServiceById);
// Create a new service
router.post('/', protect, authorize('Provider'), createService);
//Update one of my services
router.put('/:id', protect, authorize('Provider'), updateService);
//Delete one of my services
router.delete('/:id', protect, authorize('Provider'), deleteService);

module.exports = router;