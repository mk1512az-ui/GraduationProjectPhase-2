const jwt = require('jsonwebtoken');
const User = require('../models/userModel');

// Checks if user is logged in
const protect = async (req, res, next) => {
  let token;

  // Check if the request has an 'Authorization' header and it starts with 'Bearer'
  if (req.headers.authorization && req.headers.authorization.startsWith('Bearer')) {
    try {
      // Get token from header (e.g., "Bearer <token>")
      token = req.headers.authorization.split(' ')[1];

      // Verify the token using your JWT_SECRET
      const decoded = jwt.verify(token, process.env.JWT_SECRET);

      // Find the user from the database using the ID in the token
      // Attach the user object to the request, excluding the password
      req.user = await User.findById(decoded.id).select('-password');

      // Move on to the next function (e.g., the controller)
      next();
    } catch (error) {
      console.error('Token verification failed:', error.message);
      res.status(401).json({ message: 'Not authorized, token failed' });
    }
  }

  if (!token) {
    res.status(401).json({ message: 'Not authorized, no token' });
  }
};

// 2. "authorize" Middleware: Checks if user has the correct role
const authorize = (...roles) => {
  return (req, res, next) => {
    if (!req.user || !roles.includes(req.user.role)) {
      return res.status(403).json({ 
        message: `Forbidden: User role '${req.user.role}' is not authorized to access this route.` 
      });
    }
    // If the user's role is in the list of allowed roles, proceed
    next();
  };
};

module.exports = { protect, authorize };