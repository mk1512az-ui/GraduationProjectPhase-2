const Service = require('../models/serviceModel');

//Create a new service
//POST /api/services
//Private (Provider only)
const createService = async (req, res) => {
  const { serviceName, serviceDescription, paymentAmount } = req.body;
  
  try {
    const service = new Service({
      provider: req.user._id, // from 'protect' middleware
      serviceName,
      serviceDescription,
      paymentAmount,
      providerOverallRating: req.user.rating || 0
    });
    
    const createdService = await service.save();
    res.status(201).json(createdService);
  } catch (error) {
    res.status(500).json({ message: error.message });
  }
};

//Get all services from all providers
//GET /api/services
//Private (Senior/Admin)
const getAllServices = async (req, res) => {
  try {
    const services = await Service.find({}).populate('provider', 'name rating');
    res.json(services);
  } catch (error) {
    res.status(500).json({ message: error.message });
  }
};

//Get a single service by ID
//GET /api/services/:id
//Private
const getServiceById = async (req, res) => {
    try {
        const service = await Service.findById(req.params.id).populate('provider', 'name rating serviceType');
        if (service) {
            res.json(service);
        } else {
            res.status(404).json({ message: 'Service not found' });
        }
    } catch (error) {
        res.status(500).json({ message: error.message });
    }
};

//Get all services offered by the logged-in provider
//GET /api/services/my-services
//Private (Provider only)
const getMyServices = async (req, res) => {
  try {
    const services = await Service.find({ provider: req.user._id });
    res.json(services);
  } catch (error) {
    res.status(500).json({ message: error.message });
  }
};

//Update one of my services
//PUT /api/services/:id
//Private (Provider only)
const updateService = async (req, res) => {
    try {
        const service = await Service.findById(req.params.id);

        if (!service) {
            return res.status(404).json({ message: 'Service not found' });
        }

        // Check if this provider owns this service
        if (service.provider.toString() !== req.user._id.toString()) {
            return res.status(401).json({ message: 'Not authorized to update this service' });
        }

        const { serviceName, serviceDescription, paymentAmount } = req.body;
        service.serviceName = serviceName || service.serviceName;
        service.serviceDescription = serviceDescription || service.serviceDescription;
        service.paymentAmount = paymentAmount || service.paymentAmount;

        const updatedService = await service.save();
        res.json(updatedService);

    } catch (error) {
        res.status(500).json({ message: error.message });
    }
};

//Delete one of my services
//DELETE /api/services/:id
//Private (Provider only)
const deleteService = async (req, res) => {
    try {
        const service = await Service.findById(req.params.id);

        if (!service) {
            return res.status(404).json({ message: 'Service not found' });
        }

        if (service.provider.toString() !== req.user._id.toString()) {
            return res.status(401).json({ message: 'Not authorized to delete this service' });
        }

        // We should also delete related bookings and bills, but for now, just delete the service
        await service.deleteOne();
        res.json({ message: 'Service removed' });

    } catch (error) {
        res.status(500).json({ message: error.message });
    }
};

module.exports = {
  createService,
  getAllServices,
  getServiceById,
  getMyServices,
  updateService,
  deleteService,
};