const User = require('../models/userModel');
const jwt = require('jsonwebtoken');

// Helper to generate a token
const generateToken = (id) => {
  return jwt.sign({ id }, process.env.JWT_SECRET, {
    expiresIn: '30d',
  });
};

//Register a new user (Senior or Provider)
//POST /api/auth/signup
//Public
const signup = async (req, res) => {
  const { name, email, password, age, role, serviceType } = req.body;

  try {
    const userExists = await User.findOne({ email });

    if (userExists) {
      return res.status(400).json({ message: 'User already exists' });
    }

    // Create user object
    const userData = { name, email, password, age, role };
    
    // Add serviceType if the role is Provider
    if (role === 'Provider') {
      if (!serviceType) {
        return res.status(400).json({ message: 'Provider must have a service type' });
      }
      userData.serviceType = serviceType;
    }

    const user = await User.create(userData);

    if (user) {
      res.status(201).json({
        _id: user._id,
        name: user.name,
        email: user.email,
        role: user.role,
        token: generateToken(user._id),
      });
    } else {
      res.status(400).json({ message: 'Invalid user data' });
    }
  } catch (error) {
    res.status(500).json({ message: error.message });
  }
};

//Authenticate a user (Login)
//POST /api/auth/login
//Public
const login = async (req, res) => {
  const { email, password, role } = req.body; // Role

  try {
    const user = await User.findOne({ email });

    if (user && (await user.matchPassword(password))) {
      
      // Check if role matches the one selected on login
      if (user.role !== role) {
        // If it is not, return an error"
        return res.status(401).json({ message: 'Role selection is incorrect for this user' });
      }

      res.json({
        _id: user._id,
        name: user.name,
        email: user.email,
        role: user.role,
        token: generateToken(user._id),
      });
    } else {
      res.status(401).json({ message: 'Invalid email or password' });
    }
  } catch (error) {
    res.status(500).json({ message: error.message });
  }
};

//Get current user's profile
//GET /api/auth/me
//Private
const getMe = async (req, res) => {
  res.status(200).json(req.user);
};

module.exports = {
  signup,
  login,
  getMe,
};
