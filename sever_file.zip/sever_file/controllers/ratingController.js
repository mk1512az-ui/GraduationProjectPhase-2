const Rating = require('../models/ratingModel');
const Booking = require('../models/bookingModel');

//Create a new rating for a provider
//POST /api/ratings
//Private (Senior only)
const createRating = async (req, res) => {
    const { providerId, bookingId, rating, comment } = req.body;
    const seniorId = req.user._id;

    try {
        // 1. Check if this senior actually had a completed booking with this provider
        const booking = await Booking.findOne({
            _id: bookingId,
            senior: seniorId,
            provider: providerId,
            status: 'Completed' // Can only rate completed services
        });

        if (!booking) {
            return res.status(401).json({ message: 'You can only rate completed services you have booked.' });
        }

        // 2. Check if this booking has already been rated
        const existingRating = await Rating.findOne({ booking: bookingId, senior: seniorId });
        if (existingRating) {
            return res.status(400).json({ message: 'You have already rated this service' });
        }

        // 3. Create and save the new rating
        const newRating = new Rating({
            senior: seniorId,
            provider: providerId,
            booking: bookingId,
            rating: Number(rating),
            comment: comment
        });

        await newRating.save();
        
        // The 'post save' hook on the Rating model will automatically update the provider's average rating.
        
        res.status(201).json({ message: 'Rating submitted successfully' });

    } catch (error) {
        res.status(500).json({ message: error.message });
    }
};

//Get all ratings for a specific provider
//GET /api/ratings/provider/:id
//Public
const getRatingsForProvider = async (req, res) => {
    try {
        const ratings = await Rating.find({ provider: req.params.id })
            .populate('senior', 'name');
        
        res.json(ratings);
    } catch (error) {
        res.status(500).json({ message: error.message });
    }
};

module.exports = {
    createRating,
    getRatingsForProvider,
};