const Bill = require('../models/billModel');

//Get all bills for the logged-in user (Senior or Provider)
//GET /api/bills/my-bills
//Private
const getMyBills = async (req, res) => {
    try {
        let bills;
        if (req.user.role === 'Senior') {
            bills = await Bill.find({ senior: req.user._id })
                .populate('provider', 'name')
                .populate('booking', 'bookingDate');
        } else if (req.user.role === 'Provider') {
            bills = await Bill.find({ provider: req.user._id })
                .populate('senior', 'name')
                .populate('booking', 'bookingDate');
        }
        res.json(bills);
    } catch (error) {
        res.status(500).json({ message: error.message });
    }
};

//Pay a bill
//PUT /api/bills/:id/pay
//Private (Senior only)
const payBill = async (req, res) => {
    try {
        const bill = await Bill.findById(req.params.id);

        if (!bill) {
            return res.status(404).json({ message: 'Bill not found' });
        }

        // Only the senior on the bill can pay it
        if (bill.senior.toString() !== req.user._id.toString()) {
            return res.status(401).json({ message: 'Not authorized to pay this bill' });
        }
        // For our app, we just update the status to 'Paid'
        bill.status = 'Paid';
        
        const updatedBill = await bill.save();
        res.json(updatedBill);
    } catch (error) {
        res.status(500).json({ message: error.message });
    }
};

module.exports = {
    getMyBills,
    payBill,
};