import React, { useState, useEffect } from 'react';
import api from '../services/api';
import './App.css';

// This dashboard implements the "Full CRUD authority" 
const AdminDashboard = () => {
  const [users, setUsers] = useState([]);
  const [services, setServices] = useState([]);
  const [bookings, setBookings] = useState([]);
  const [error, setError] = useState('');
  const [loading, setLoading] = useState(true);

  const fetchData = async () => {
    try {
      setLoading(true);
      // Fetch all data from the admin routes
      const [userRes, serviceRes, bookingRes] = await Promise.all([
        api.get('/admin/users'),     // Get all users
        api.get('/admin/services'),  // Get all services
        api.get('/admin/bookings')   // Get all bookings
      ]);
      setUsers(userRes.data);
      setServices(serviceRes.data);
      setBookings(bookingRes.data);
      setError('');
    } catch (err) {
      // Use err.message for mock errors, err.response.data.message for real API
      setError(err.response?.data?.message || err.message || 'Failed to fetch admin data');
    } finally {
      setLoading(false);
    }
  };

  useEffect(() => {
    fetchData();
  }, []);

  // Handler for deleting a user
  const handleDeleteUser = async (userId) => {
    // In a real app, use a custom modal, not window.confirm
    if (window.confirm('Are you sure you want to delete this user? This cannot be undone.')) {
      try {
        await api.delete(`/admin/users/${userId}`);
        alert('User deleted');
        fetchData(); // Refresh data
      } catch (err) {
        alert(err.response?.data?.message || err.message || 'Failed to delete user');
      }
    }
  };

  // Handler for deleting a service
  const handleDeleteService = async (serviceId) => {
    if (window.confirm('Are you sure you want to delete this service?')) {
      try {
        await api.delete(`/admin/services/${serviceId}`);
        alert('Service deleted');
        fetchData(); // Refresh data
      } catch (err) {
        alert(err.response?.data?.message || err.message || 'Failed to delete service');
      }
    }
  };

  // Handler for deleting a booking
  const handleDeleteBooking = async (bookingId) => {
    if (window.confirm('Are you sure you want to delete this booking?')) {
      try {
        await api.delete(`/admin/bookings/${bookingId}`);
        alert('Booking deleted');
        fetchData(); // Refresh data
      } catch (err) {
        alert(err.response?.data?.message || err.message || 'Failed to delete booking');
      }
    }
  };

  if (loading) return <div>Loading dashboard...</div>;

  // Consistent styling for tables
  const tableStyle = { width: '100%', borderCollapse: 'collapse', marginBottom: '20px' };
  const thStyle = { padding: '8px', border: '1px solid #ddd', background: '#f4f4f4', textAlign: 'left' };
  const tdStyle = { padding: '8px', border: '1px solid #ddd' };
  const deleteButtonStyle = { color: 'red', cursor: 'pointer', background: 'none', border: 'none', padding: '0' };

  return (
    <div style={{ padding: '20px', fontFamily: 'Arial, sans-serif' }}>
      <h2>Admin Dashboard</h2>
      {error && <p style={{ color: 'red' }}>{error}</p>}

      {/* 1. Manage Seniors & Providers */}
      <section style={{ marginBottom: '20px', overflowX: 'auto' }}>
        <h3>User Management ({users.length} users)</h3>
        <table style={tableStyle}>
          <thead>
            <tr>
              <th style={thStyle}>Name</th>
              <th style={thStyle}>Email</th>
              <th style={thStyle}>Role</th>
              <th style={thStyle}>Age</th>
              <th style={thStyle}>Action</th>
            </tr>
          </thead>
          <tbody>
            {users.map(user => (
              <tr key={user._id}>
                <td style={tdStyle}>{user.name}</td>
                <td style={tdStyle}>{user.email}</td>
                <td style={tdStyle}>{user.role}</td>
                <td style={tdStyle}>{user.age}</td>
                <td style={{...tdStyle, textAlign: 'center'}}>
                  <button onClick={() => handleDeleteUser(user._id)} style={deleteButtonStyle}>Delete</button>
                </td>
              </tr>
            ))}
          </tbody>
        </table>
      </section>
      
      {/* 2. Manage Services */}
      <section style={{ marginBottom: '20px', overflowX: 'auto' }}>
        <h3>Service Management ({services.length} services)</h3>
        <table style={tableStyle}>
          <thead>
            <tr>
              <th style={thStyle}>Service Name</th>
              <th style={thStyle}>Description</th>
              <th style={thStyle}>Price</th>
              <th style={thStyle}>Provider</th>
              <th style={thStyle}>Action</th>
            </tr>
          </thead>
          <tbody>
            {services.map(service => (
              <tr key={service._id}>
                <td style={tdStyle}>{service.serviceName}</td>
                <td style={tdStyle}>{service.serviceDescription}</td>
                <td style={tdStyle}>${service.paymentAmount?.toFixed(2)}</td>
                <td style={tdStyle}>{service.provider?.name || 'N/A'}</td>
                <td style={{...tdStyle, textAlign: 'center'}}>
                  <button onClick={() => handleDeleteService(service._id)} style={deleteButtonStyle}>Delete</button>
                </td>
              </tr>
            ))}
          </tbody>
        </table>
      </section>

      {/* 3. Manage Bookings */}
      <section style={{ overflowX: 'auto' }}>
        <h3>Booking Management ({bookings.length} bookings)</h3>
        <table style={tableStyle}>
          <thead>
            <tr>
              <th style={thStyle}>Service</th>
              <th style={thStyle}>Senior</th>
              <th style={thStyle}>Provider</th>
              <th style={thStyle}>Date</th>
              <th style={thStyle}>Status</th>
              <th style={thStyle}>Action</th>
            </tr>
          </thead>
          <tbody>
            {bookings.map(booking => (
              <tr key={booking._id}>
                <td style={tdStyle}>{booking.service?.serviceName || 'N/A'}</td>
                <td style={tdStyle}>{booking.senior?.name || 'N/A'}</td>
                <td style={tdStyle}>{booking.provider?.name || 'N/A'}</td>
                <td style={tdStyle}>{new Date(booking.bookingDate).toLocaleDateString()}</td>
                <td style={tdStyle}>{booking.status}</td>
                <td style={{...tdStyle, textAlign: 'center'}}>
                  <button onClick={() => handleDeleteBooking(booking._id)} style={deleteButtonStyle}>Delete</button>
                </td>
              </tr>
            ))}
          </tbody>
        </table>
      </section>
    </div>
  );
};

export default AdminDashboard;