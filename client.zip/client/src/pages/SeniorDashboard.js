import React, { useState, useEffect } from 'react';
import api from '../services/api';
import './App.css';
//"Senior Dashboard"
const SeniorDashboard = () => {
  const [services, setServices] = useState([]);
  const [bookings, setBookings] = useState([]);
  const [recommendations, setRecommendations] = useState([]);
  const [bills, setBills] = useState([]);
  const [error, setError] = useState('');
  const [loading, setLoading] = useState(true);

  // Function to fetch all data
  const fetchData = async () => {
    try {
      setLoading(true);
      const [serviceRes, bookingRes, recoRes, billRes] = await Promise.all([
        api.get('/services'),             // Get all available services
        api.get('/bookings/my-bookings'), // Get my bookings
        api.get('/recommendations'),      // Get my recommendations
        api.get('/bills/my-bills')        // Get my bills
      ]);
      
      setServices(serviceRes.data);
      setBookings(bookingRes.data);
      setRecommendations(recoRes.data.recommendations || []);
      setBills(billRes.data);
      setError('');
    } catch (err) {
      setError(err.response?.data?.message || 'Failed to fetch dashboard data');
    } finally {
      setLoading(false);
    }
  };

  // Run fetchData
  useEffect(() => {
    fetchData();
  }, []);

  //"Book Service"
  const handleBookService = async (serviceId) => {
    const bookingDate = prompt('Enter booking date (e.g., 2025-12-25):');
    if (!bookingDate) return;

    try {
      await api.post('/bookings', { serviceId, bookingDate });
      alert('Service booked successfully!');
      fetchData(); // Refresh all data on the dashboard
    } catch (err) {
      alert(err.response?.data?.message || 'Failed to book service');
    }
  };

  //"Pay Bill"
  const handlePayBill = async (billId) => {
    if (window.confirm('Are you sure you want to pay this bill?')) {
        try {
            await api.put(`/bills/${billId}/pay`);
            alert('Bill paid successfully!');
            fetchData(); // Refresh all data
        } catch (err) {
            alert(err.response?.data?.message || 'Failed to pay bill');
        }
    }
  };

  //"Rate Provider"
  const handleRateProvider = async (booking) => {
    if (booking.status !== 'Completed') {
        alert('You can only rate completed services.');
        return;
    }
    const rating = prompt('Enter rating (1-5):');
    const comment = prompt('Enter a comment (optional):');
    if (!rating || rating < 1 || rating > 5) {
        alert('Invalid rating. Must be between 1 and 5.');
        return;
    }
    
    try {
        await api.post('/ratings', {
            providerId: booking.provider._id,
            bookingId: booking._id,
            rating: Number(rating),
            comment: comment
        });
        alert('Thank you for your rating!');
        fetchData(); // Refresh data
    } catch (err) {
        alert(err.response?.data?.message || 'Failed to submit rating. You may have already rated this service.');
    }
  };


  if (loading) return <div>Loading dashboard...</div>;

  return (
    <div style={{ padding: '20px' }}>
      <h2>Senior Dashboard</h2>
      {error && <p style={{ color: 'red' }}>{error}</p>}

      {/* 1. Personalized Recommendations later on)*/}
      <section style={{ marginBottom: '20px', padding: '10px', border: '1px solid #007bff', borderRadius: '5px', background: '#f8f9fa' }}>
        <h3>Recommended for You</h3>
        {recommendations.length > 0 ? (
          recommendations.map(rec => (
            <div key={rec._id} style={{ border: '1px solid #17a2b8', background: 'white', padding: '10px', marginBottom: '5px', borderRadius: '5px' }}>
              <strong>{rec.serviceName}</strong> (From your AI/ML model)
            </div>
          ))
        ) : <p>No recommendations available yet.</p>}
      </section>

      {/* 2. View/Search Services*/}
      <section style={{ marginBottom: '20px' }}>
        <h3>Available Services</h3>
        <table style={{ width: '100%', borderCollapse: 'collapse', tableLayout: 'fixed' }}>
          <thead style={{ background: '#f4f4f4' }}>
            <tr>
              <th style={{padding: '8px', border: '1px solid #ddd', width: '20%'}}>Service</th>
              <th style={{padding: '8px', border: '1px solid #ddd', width: '30%'}}>Description</th>
              <th style={{padding: '8px', border: '1px solid #ddd', width: '15%'}}>Provider</th>
              <th style={{padding: '8px', border: '1px solid #ddd', width: '10%'}}>Rating</th>
              <th style={{padding: '8px', border: '1px solid #ddd', width: '10%'}}>Price ($)</th>
              <th style={{padding: '8px', border: '1px solid #ddd', width: '15%'}}>Action</th>
            </tr>
          </thead>
          <tbody>
            {services.map(service => (
              <tr key={service._id}>
                <td style={{padding: '8px', border: '1px solid #ddd'}}>{service.serviceName}</td>
                <td style={{padding: '8px', border: '1px solid #ddd'}}>{service.serviceDescription}</td>
                <td style={{padding: '8px', border: '1px solid #ddd'}}>{service.provider.name}</td>
                <td style={{padding: '8px', border: '1px solid #ddd', textAlign: 'center'}}>{service.provider.rating.toFixed(1)} ★</td>
                <td style={{padding: '8px', border: '1px solid #ddd', textAlign: 'center'}}>{service.paymentAmount.toFixed(2)}</td>
                <td style={{padding: '8px', border: '1px solid #ddd', textAlign: 'center'}}>
                  <button onClick={() => handleBookService(service._id)}>Book Now</button>
                </td>
              </tr>
            ))}
          </tbody>
        </table>
      </section>

      {/* 3. My Bookings (and Pay Bills / Rate Provider)*/}
      <section style={{ marginBottom: '20px' }}>
        <h3>My Bookings</h3>
        {bookings.length > 0 ? (
          bookings.map(booking => (
            <div key={booking._id} style={{ border: '1px solid #ddd', padding: '10px', marginBottom: '10px', background: 'white' }}>
              <p><strong>Service:</strong> {booking.service.serviceName}</p>
              <p><strong>Provider:</strong> {booking.provider.name}</p>
              <p><strong>Date:</strong> {new Date(booking.bookingDate).toLocaleDateString()}</p>
              <p><strong>Status:</strong> <span style={{fontWeight: 'bold', color: booking.status === 'Completed' ? 'green' : 'black'}}>{booking.status}</span></p>
              {booking.status === 'Completed' && <button onClick={() => handleRateProvider(booking)} style={{marginRight: '5px'}}>Rate Provider</button>}
            </div>
          ))
        ) : <p>You have no active bookings.</p>}
      </section>

      {/* 4. My Bills*/}
      <section>
        <h3>My Bills</h3>
        {bills.map(bill => (
            <div key={bill._id} style={{ border: '1px solid #ddd', padding: '10px', marginBottom: '10px', background: bill.status === 'Paid' ? '#e9f7ef' : 'white' }}>
              <p><strong>Provider:</strong> {bill.provider.name}</p>
              <p><strong>Amount:</strong> ${bill.amount.toFixed(2)}</p>
              <p><strong>Status:</strong> <span style={{fontWeight: 'bold', color: bill.status === 'Paid' ? 'green' : 'red'}}>{bill.status}</span></p>
              {bill.status === 'Pending' && <button onClick={() => handlePayBill(bill._id)}>Pay Now</button>}
            </div>
          ))}
      </section>
    </div>
  );
};

export default SeniorDashboard;