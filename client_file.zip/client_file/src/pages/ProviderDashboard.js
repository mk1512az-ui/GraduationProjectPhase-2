import React, { useState, useEffect } from 'react';
import api from '../services/api';
import './App.css';
//"Provider Dashboard"
const ProviderDashboard = () => {
  const [myServices, setMyServices] = useState([]);
  const [myBookings, setMyBookings] = useState([]);
  const [error, setError] = useState('');
  const [loading, setLoading] = useState(true);

  // Form state for adding a new service
  const [serviceName, setServiceName] = useState('');
  const [serviceDescription, setServiceDescription] = useState('');
  const [paymentAmount, setPaymentAmount] = useState('');

  const fetchData = async () => {
    try {
      setLoading(true);
      // Fetch data in parallel
      const [servicesRes, bookingsRes] = await Promise.all([
        api.get('/services/my-services'), // Get only *my* services
        api.get('/bookings/my-bookings')  // Get bookings for *me*
      ]);
      setMyServices(servicesRes.data);
      setMyBookings(bookingsRes.data);
      setError('');
    } catch (err) {
      setError(err.response?.data?.message || 'Failed to fetch data');
    } finally {
      setLoading(false);
    }
  };

  // Fetch data on component mount
  useEffect(() => {
    fetchData();
  }, []);

  // Handler for "Add Service" form
  const handleAddService = async (e) => {
    e.preventDefault();
    try {
      await api.post('/services', { serviceName, serviceDescription, paymentAmount: Number(paymentAmount) });
      alert('Service added!');
      // Clear form
      setServiceName('');
      setServiceDescription('');
      setPaymentAmount('');
      fetchData(); // Refresh data
    } catch (err) {
      alert(err.response?.data?.message || 'Failed to add service');
    }
  };

  // Handler for "Delete Service" button
  const handleDeleteService = async (serviceId) => {
    if (window.confirm('Are you sure you want to delete this service?')) {
        try {
            await api.delete(`/services/${serviceId}`);
            alert('Service deleted');
            fetchData(); // Refresh
        } catch (err) {
            alert(err.response?.data?.message || 'Failed to delete service');
        }
    }
  };

  // Handler to update booking status (e.g., to "Completed")
  const handleUpdateBookingStatus = async (bookingId, newStatus) => {
    try {
        await api.put(`/bookings/${bookingId}/status`, { status: newStatus });
        alert(`Booking marked as ${newStatus}`);
        fetchData(); // Refresh
    } catch (err) {
        alert(err.response?.data?.message || 'Failed to update status');
    }
  };


  if (loading) return <div>Loading dashboard...</div>;

  return (
    <div style={{ padding: '20px' }}>
      <h2>Provider Dashboard</h2>
      {error && <p style={{ color: 'red' }}>{error}</p>}

      {/* 1. Manage Services (Add) */}
      <section style={{ marginBottom: '20px', padding: '10px', border: '1px solid #ddd', borderRadius: '5px', background: '#f8f9fa' }}>
        <h3>Add a New Service</h3>
        <form onSubmit={handleAddService}>
          <input type="text" placeholder="Service Name" value={serviceName} onChange={(e) => setServiceName(e.target.value)} required style={{marginRight: '5px', padding: '8px'}} />
          <input type="text" placeholder="Description" value={serviceDescription} onChange={(e) => setServiceDescription(e.target.value)} required style={{marginRight: '5px', padding: '8px', width: '300px'}} />
          <input type="number" placeholder="Price ($)" value={paymentAmount} onChange={(e) => setPaymentAmount(e.target.value)} required style={{marginRight: '5px', padding: '8px'}} />
          <button type="submit" style={{background: '#28a745', color: 'white'}}>Add Service</button>
        </form>
      </section>

      {/* 2. Manage Services (View/Delete) */}
      <section style={{ marginBottom: '20px' }}>
        <h3>My Listed Services</h3>
        <table style={{ width: '100%', borderCollapse: 'collapse' }}>
          <thead style={{ background: '#f4f4f4' }}>
            <tr>
              <th style={{padding: '8px', border: '1px solid #ddd'}}>Name</th>
              <th style={{padding: '8px', border: '1px solid #ddd'}}>Description</th>
              <th style={{padding: '8px', border: '1px solid #ddd'}}>Price ($)</th>
              <th style={{padding: '8px', border: '1px solid #ddd'}}>Action</th>
            </tr>
          </thead>
          <tbody>
            {myServices.map(service => (
              <tr key={service._id}>
                <td style={{padding: '8px', border: '1px solid #ddd'}}>{service.serviceName}</td>
                <td style={{padding: '8px', border: '1px solid #ddd'}}>{service.serviceDescription}</td>
                <td style={{padding: '8px', border: '1px solid #ddd'}}>${service.paymentAmount.toFixed(2)}</td>
                <td style={{padding: '8px', border: '1px solid #ddd'}}>
                  <button onClick={() => handleDeleteService(service._id)} style={{color: 'red'}}>Delete</button>
                </td>
              </tr>
            ))}
          </tbody>
        </table>
      </section>

      {/* 3. View Bookings */}
      <section>
        <h3>Bookings for Me</h3>
        {myBookings.map(booking => (
          <div key={booking._id} style={{ border: '1px solid #ddd', padding: '10px', marginBottom: '10px', background: 'white' }}>
            <p><strong>Service:</strong> {booking.service.serviceName}</p>
            <p><strong>Senior:</strong> {booking.senior.name} ({booking.senior.email})</p>
            <p><strong>Date:</strong> {new Date(booking.bookingDate).toLocaleDateString()}</p>
            <p><strong>Status:</strong> <span style={{fontWeight: 'bold'}}>{booking.status}</span></p>
            {booking.status === 'Pending' && <button onClick={() => handleUpdateBookingStatus(booking._id, 'Confirmed')} style={{marginRight: '5px', background: 'blue', color: 'white'}}>Confirm</button>}
            {booking.status === 'Confirmed' && <button onClick={() => handleUpdateBookingStatus(booking._id, 'Completed')} style={{marginRight: '5px', background: 'green', color: 'white'}}>Mark as Completed</button>}
          </div>
        ))}
      </section>
    </div>
  );
};

export default ProviderDashboard;