import React from 'react';
import { useAuth } from '../context/AuthContext';
import { Link } from 'react-router-dom';
import './App.css';
const HomePage = () => {
  const { user, logout } = useAuth();

  return (
    <div style={{ padding: '20px' }}>
      <h1>Welcome to Reciplink</h1>
      <p>Revolutionizing Elderly Care</p>
      
      {user ? (
        <div>
          <p>Hello, {user.name} ({user.role})</p>
          {user.role === 'Senior' && <Link to="/dashboard/senior">Go to My Dashboard</Link>}
          {user.role === 'Provider' && <Link to="/dashboard/provider">Go to My Dashboard</Link>}
          {user.role === 'Admin' && <Link to="/dashboard/admin">Go to My Dashboard</Link>}
          <br />
          <button onClick={logout} style={{ marginTop: '10px' }}>Logout</button>
        </div>
      ) : (
        <div>
          <Link to="/login">Login</Link> | <Link to="/signup">Sign Up</Link>
        </div>
      )}
    </div>
  );
};

export default HomePage;