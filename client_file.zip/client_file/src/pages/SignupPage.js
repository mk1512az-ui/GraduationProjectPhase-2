import React, { useState } from 'react';
import { useAuth } from '../context/AuthContext';
import { useNavigate, Link } from 'react-router-dom';
import './App.css';
const SignupPage = () => {
  const [name, setName] = useState('');
  const [email, setEmail] = useState('');
  const [password, setPassword] = useState('');
  const [age, setAge] = useState('');
  const [role, setRole] = useState('Senior');
  const [serviceType, setServiceType] = useState(''); // Specific to Provider
  const [error, setError] = useState('');
  
  const { signup } = useAuth();
  const navigate = useNavigate();

  const handleSubmit = async (e) => {
    e.preventDefault();
    setError('');
    
    // Validate that 'Provider' role has a serviceType
    if (role === 'Provider' && !serviceType) {
      setError('Providers must select a service type.');
      return;
    }

    try {
      const user = await signup(name, email, password, Number(age), role, serviceType);
      
      // Redirect to the correct dashboard after signup
      if (user.role === 'Senior') {
        navigate('/dashboard/senior');
      } else if (user.role === 'Provider') {
        navigate('/dashboard/provider');
      }
      
    } catch (err) {
      setError(err.message || 'Failed to sign up');
    }
  };

  return (
    <div style={{ padding: '20px', maxWidth: '400px', margin: 'auto', border: '1px solid #ddd', borderRadius: '5px', marginTop: '20px' }}>
      <h2 style={{ textAlign: 'center' }}>Sign Up</h2>
      {error && <p style={{ color: 'red', textAlign: 'center' }}>{error}</p>}
      <form onSubmit={handleSubmit}>
        
        <div style={{ marginBottom: '10px' }}>
          <label>I am a:</label><br />
          <select value={role} onChange={(e) => setRole(e.target.value)} style={{ width: '100%', padding: '8px' }}>
            <option value="Senior">Senior (or family member)</option>
            <option value="Provider">Service Provider</option>
          </select>
        </div>

        <div style={{ marginBottom: '10px' }}>
          <label>Full Name:</label><br />
          <input type="text" value={name} onChange={(e) => setName(e.target.value)} required style={{ width: '95%', padding: '8px' }} />
        </div>
        
        <div style={{ marginBottom: '10px' }}>
          <label>Email:</label><br />
          <input type="email" value={email} onChange={(e) => setEmail(e.target.value)} required style={{ width: '95%', padding: '8px' }} />
        </div>
        
        <div style={{ marginBottom: '10px' }}>
          <label>Password (min 6 chars):</label><br />
          <input type="password" value={password} onChange={(e) => setPassword(e.target.value)} required minLength="6" style={{ width: '95%', padding: '8px' }} />
        </div>

        <div style={{ marginBottom: '10px' }}>
          <label>Age:</label><br />
          <input type="number" value={age} onChange={(e) => setAge(e.target.value)} required style={{ width: '95%', padding: '8px' }} />
        </div>

        {/* This field ONLY appears if role is 'Provider' */}
        {role === 'Provider' && (
          <div style={{ marginBottom: '10px' }}>
            <label>My Service (matches core modules):</label><br />
            <select value={serviceType} onChange={(e) => setServiceType(e.target.value)} style={{ width: '100%', padding: '8px' }}>
              <option value="">-- Select Your Service --</option>
              <option value="Caregiving">Caregiving</option>
              <option value="Meal Making">Meal Making</option>
              <option value="Transportation">Transportation</option>
              <option value="Companionship">Companionship</option>
            </select>
          </div>
        )}

        <button type="submit" style={{ width: '100%', padding: '10px', background: '#28a745', color: 'white', border: 'none', borderRadius: '5px', cursor: 'pointer' }}>Sign Up</button>
      </form>
      <p style={{ textAlign: 'center', marginTop: '10px' }}>
        Already have an account? <Link to="/login">Login</Link>
      </p>
    </div>
  );
};

export default SignupPage;