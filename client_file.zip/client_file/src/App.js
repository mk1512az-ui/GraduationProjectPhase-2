import React from 'react';
import { Routes, Route } from 'react-router-dom';
import LoginPage from './pages/LoginPage';
import SignupPage from './pages/SignupPage';
import HomePage from './pages/HomePage';
import SeniorDashboard from './pages/SeniorDashboard';
import ProviderDashboard from './pages/ProviderDashboard';
import AdminDashboard from './pages/AdminDashboard';
import ProtectedRoute from './components/ProtectedRoute';

function App() {
  return (
    <div className="App">
      {/* You can add a <Navbar /> component here */}
      <Routes>
        <Route path="/" element={<HomePage />} />
        <Route path="/login" element={<LoginPage />} />
        <Route path="/signup" element={<SignupPage />} />

        {/* Protected Routes: Only accessible if logged in */}
        
        {/* Senior Dashboard */}
        <Route 
          path="/dashboard/senior" 
          element={
            <ProtectedRoute roles={['Senior']}>
              <SeniorDashboard />
            </ProtectedRoute>
          } 
        />
        
        {/* Provider Dashboard  */}
        <Route 
          path="/dashboard/provider" 
          element={
            <ProtectedRoute roles={['Provider']}>
              <ProviderDashboard />
            </ProtectedRoute>
          } 
        />
        
        {/* Admin Dashboard */}
        <Route 
          path="/dashboard/admin" 
          element={
            <ProtectedRoute roles={['Admin']}>
              <AdminDashboard />
            </ProtectedRoute>
          } 
        />
        
      </Routes>
    </div>
  );
}

export default App;
